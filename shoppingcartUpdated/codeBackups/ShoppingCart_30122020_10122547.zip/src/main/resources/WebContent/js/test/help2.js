function showMessage2()
{
	alert("From JS file 2 !!");   
}

