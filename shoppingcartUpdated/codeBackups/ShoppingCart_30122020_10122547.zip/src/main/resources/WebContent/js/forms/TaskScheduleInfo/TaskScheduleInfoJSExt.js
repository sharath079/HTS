

function doAfterPanelRefreshedForTaskScheduleInfoExt()
{
    //Custom handling
}



function doAfterPanelInitializedForTaskScheduleInfoExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForTaskScheduleInfoExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForTaskScheduleInfoExt(fieldName)
{
    //Custom handling
}



function processResultRowForTaskScheduleInfoExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForTaskScheduleInfoExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForTaskScheduleInfoExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForTaskScheduleInfoExt(customEventName)
{
    //Custom handling
}

