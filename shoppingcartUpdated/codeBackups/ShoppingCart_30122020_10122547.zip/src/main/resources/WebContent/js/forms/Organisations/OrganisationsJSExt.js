

function doAfterPanelRefreshedForOrganisationsExt()
{
    //Custom handling
}



function doAfterPanelInitializedForOrganisationsExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForOrganisationsExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForOrganisationsExt(fieldName)
{
    //Custom handling
}



function processResultRowForOrganisationsExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForOrganisationsExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForOrganisationsExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForOrganisationsExt(customEventName)
{
    //Custom handling
}

