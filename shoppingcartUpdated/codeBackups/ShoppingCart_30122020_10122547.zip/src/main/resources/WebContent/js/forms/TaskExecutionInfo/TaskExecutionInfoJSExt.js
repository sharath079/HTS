

function doAfterPanelRefreshedForTaskExecutionInfoExt()
{
    //Custom handling
}



function doAfterPanelInitializedForTaskExecutionInfoExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForTaskExecutionInfoExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForTaskExecutionInfoExt(fieldName)
{
    //Custom handling
}



function processResultRowForTaskExecutionInfoExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForTaskExecutionInfoExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForTaskExecutionInfoExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForTaskExecutionInfoExt(customEventName)
{
    //Custom handling
}

