package com.shoppingcart.controller.forms.base;
//import javax.faces.bean.ManagedBean;
import com.vw.runtime.RulesBean;
/**
*
 * @author  Srikanth Brahmadevara: Harivara Technology Solutions, CODE GENERATED
* 
*/
/*@ManagedBean(name = "OrderItemLabelBean")*/
public class OrderItemLabel extends RulesBean{
	public String getorderItemIdFieldName() {return "orderItemId";} public String orderItemId_LABEL_ENGLISH = "Primary Key";
		public String getoidFieldName() {return "oid";} public String oid_LABEL_ENGLISH = "Oid";
	public String getprodIdFieldName() {return "prodId";} public String prodId_LABEL_ENGLISH = "ProdId";
	public String getprodQntyFieldName() {return "prodQnty";} public String prodQnty_LABEL_ENGLISH = "ProdQnty";
	public String getprodUnitPriceFieldName() {return "prodUnitPrice";} public String prodUnitPrice_LABEL_ENGLISH = "ProdUnitPrice";
	public String getsubTotalAmtFieldName() {return "subTotalAmt";} public String subTotalAmt_LABEL_ENGLISH = "SubTotalAmt";

	
	public String getvwLastModifiedDateFieldName() {return "vwLastModifiedDate";} public String vwLastModifiedDate_LABEL_ENGLISH = "Update Date";
	public String getvwLastModifiedTimeFieldName() {return "vwLastModifiedTime";} public String vwLastModifiedTime_LABEL_ENGLISH = "Update Time";
	public String getvwLastActionFieldName() {return "vwLastAction";} public String vwLastAction_LABEL_ENGLISH = "Last Action";
	public String getvwModifiedByFieldName() {return "vwModifiedBy";} public String vwModifiedBy_LABEL_ENGLISH = "Modified By";
	public String getvwTxnRemarksFieldName() {return "vwTxnRemarks";} public String vwTxnRemarks_LABEL_ENGLISH = "Remarks";
	public String getvwTxnStatusFieldName() {return "vwTxnStatus";} public String vwTxnStatus_LABEL_ENGLISH = "Status";
	public String LANG_ENGLISH = "ENGLISH";
	public String getLabel(String sBeanField)
	{
		return getLabel(sBeanField, LANG_ENGLISH);
	}
	public String getLabel(String sBeanField, String sLang)
	{
		String sBeanFieldLabel = "<<No Label Found !!!>>";
		if (sBeanField.matches((getorderItemIdFieldName()))) sBeanFieldLabel = orderItemId_LABEL_ENGLISH;
				if (sBeanField.matches((getoidFieldName()))) sBeanFieldLabel = oid_LABEL_ENGLISH;
		if (sBeanField.matches((getprodIdFieldName()))) sBeanFieldLabel = prodId_LABEL_ENGLISH;
		if (sBeanField.matches((getprodQntyFieldName()))) sBeanFieldLabel = prodQnty_LABEL_ENGLISH;
		if (sBeanField.matches((getprodUnitPriceFieldName()))) sBeanFieldLabel = prodUnitPrice_LABEL_ENGLISH;
		if (sBeanField.matches((getsubTotalAmtFieldName()))) sBeanFieldLabel = subTotalAmt_LABEL_ENGLISH;

		return sBeanFieldLabel;
	}
}
