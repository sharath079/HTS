function initializePageOnLoadForCartItem()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForCartItem;
