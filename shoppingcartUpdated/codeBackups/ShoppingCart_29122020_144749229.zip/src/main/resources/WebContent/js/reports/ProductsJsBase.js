$(document).ready(function() {
	initializeReportInfo();
	initializePageLevelData();
});

var cartItemDataTableRowTemplate = "";
cartItemTbodyTag = "";

function initializePageLevelData()
{
	
	
	
	var cartItemDiv = $('[data-name="CartItem"]');
	cartItemTbodyTag = cartItemDiv.find('tbody').first();
	cartItemDataTableRowTemplate = cartItemTbodyTag.find('tr').first()[0].outerHTML;
	
}
function getContextPath()
{
    return "";
}
function initializeReportInfo()
{
	initializePageOnload();
	var paramsMap = getQueryParams();
	
	initDatePicker();
	//initMonthDatePicker();
	//initYearDatePicker();
	
    getPageDataInfo();
}
function getPageDataInfo()
{
    var urlContextPath = getContextPath();
	var dataObj = getQueryParams();	
	dataObj.noOfRecordsAlreadyFetched = 0;
	dataObj.noOfRecordsToFetch = 1000000;
	dataObj.objectType = "Products";
    $.ajax({
        context: {
            'errorMessage': "abcd"
        },
        error: function (responseData) {
            closePopUp();
            showAlert(this.errorMessage);
        },
        dataType: 'json',
        type: 'GET',        
        url : urlContextPath + '/getReportInfo' +'?loginbranchid='+getCookie("loginbranchid")+'&employeeid='+getCookie("employeeid")+'&issuperuser='+getCookie("issuperuser"),
        data: dataObj,
        success: function (responseData) {
            closePopUp();
            if (responseData['alert'])
            {
                showAlert(responseData['alert']);
            }
            if (responseData['success'] == 1)
            {
                var fieldsDataWithoutOverrideWhereClause = responseData['fieldsDataWithoutOverrideWhereClause'];                
                   
                	var products = fieldsDataWithoutOverrideWhereClause['products'];                
		                
		                
		                var productName = products['productName'];
		                $('[data-name="ProductName"]').text(productName);
		                
		                
		                var productDescription = products['productDescription'];
		                $('[data-name="ProductDescription"]').text(productDescription);
		                
		                
		                var productPrice = products['productPrice'];
		                $('[data-name="ProductPrice"]').text(productPrice);
		                
		                
		                var productUnitType = products['productUnitType'];
		                $('[data-name="ProductUnitType"]').text(productUnitType);
		                
		                
		                var pID = products['pID'];
		                $('[data-name="PID"]').text(pID);
		                                
                
                var fieldsDataWithOverrideWhereClause = responseData['fieldsDataWithOverrideWhereClause'];                
	                                
			    var layoutCustomDataFieldsObject = responseData['layoutCustomDataFieldsObject'];               
                
                var tablesData = responseData['tablesData'];
                                  
                var cartItemDataRowsList = tablesData['cartItemDataRowsList'];                
                displayCartItem(cartItemDataRowsList);
                
                var graphsData = responseData['graphsData'];
                
            }
        }
    });
}

 


function displayCartItem(cartItem, parentElement)
{
	var paramsMap = "";
    var cartItemDiv = $('[data-name="CartItem"]');
	if(!(typeof parentElement === 'string' || parentElement instanceof String || typeof parentElement === 'undefined'))
	{
	        cartItemDiv = parentElement.find('[data-name="CartItem"]');
	        cartItemTbodyTag = cartItemDiv.find('tbody').first();
			cartItemDataTableRowTemplate = cartItemTbodyTag.find('tr').first()[0].outerHTML;	        	       	  
    }
    cartItemTbodyTag.empty();
    for (var i = 0; i < cartItem.length; i++)
    {
        var cartItemObject = cartItem[i];
          
        var productId = cartItemObject['productId'];    	
          
        var productQuantity = cartItemObject['productQuantity'];    	
          
        var productUnitPrice = cartItemObject['productUnitPrice'];    	
          
        var subTotalAmount = cartItemObject['subTotalAmount'];    	
          
        var userId = cartItemObject['userId'];    	
                   
             
		         
        var lineItemsListRowObj = $(cartItemDataTableRowTemplate); 
          
        	lineItemsListRowObj.find('[data-name="ProductId"]').text(productId);
          
        	lineItemsListRowObj.find('[data-name="ProductQuantity"]').text(productQuantity);
          
        	lineItemsListRowObj.find('[data-name="ProductUnitPrice"]').text(productUnitPrice);
          
        	lineItemsListRowObj.find('[data-name="SubTotalAmount"]').text(subTotalAmount);
          
        	lineItemsListRowObj.find('[data-name="UserId"]').text(userId);
                   
         
    	lineItemsListRowObj[0].setAttribute('data-row-info', JSON.stringify(cartItemObject));
        processQueryResultItemDataObject(cartItemObject, "cartItem", lineItemsListRowObj, parentElement);
            
    	cartItemTbodyTag.append(lineItemsListRowObj);
     }
     processQueryResultList(cartItem, "cartItem");
}

function getParametersFromURLAndSearchFields()
{
	var paramsMap = getQueryParams();
	//Override URL parameters values With search field values if same parameter name exists
	var searchDiv = $('[data-name="BalanceSheetReportSearchDiv"]');
	var searchFieldsList = searchDiv.find('[data-is-search-field="1"]');
	for (var i = 0; i < searchFieldsList.length; i++)
	{
		var searchFieldDiv = $(searchFieldsList[i]);
		var parameterName = searchFieldDiv.data('parameter-name');
		var userInputValue = searchFieldDiv.find('[data-is-search-input-field ="1"]').val();
		if(paramsMap.hasOwnProperty(parameterName))
		{
			paramsMap.parameterName = userInputValue;
		}
		else
		{
			paramsMap[parameterName] = userInputValue;
		}
	}
	return paramsMap;	
}


