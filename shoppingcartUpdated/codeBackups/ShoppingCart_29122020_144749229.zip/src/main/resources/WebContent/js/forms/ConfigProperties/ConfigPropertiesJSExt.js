

function doAfterPanelRefreshedForConfigPropertiesExt()
{
    //Custom handling
}



function doAfterPanelInitializedForConfigPropertiesExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForConfigPropertiesExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForConfigPropertiesExt(fieldName)
{
    //Custom handling
}



function processResultRowForConfigPropertiesExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForConfigPropertiesExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForConfigPropertiesExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForConfigPropertiesExt(customEventName)
{
    //Custom handling
}

