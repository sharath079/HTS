function processQueryResultItemDataObject(dataObject,  tableDataName, htmlRowObject, parentElement)
{
}
function processQueryResultList( resultList,  tableDataName)
{
}
