package com.shoppingcart.bean;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import com.vw.runtime.RulesBean;
@SuppressWarnings("unused")
/**
 * @author  Srikanth Brahmadevara: Harivara Technology Solutions, CODE GENERATED
 */
public class TaskExecutionInfoSearch extends RulesBean implements java.io.Serializable
{
	/*private static final long serialVersionUID = 1L;
	private java.lang.Integer taskExecutionInfoId ;
		private $$JAVA_FIELD_TYPE$$ taskTimeCalculationType $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ firstRunDateCalculationMethod $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ firstRunDateGapInYears $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ firstRunDateGapInMonths $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ firstRunDateGapInDays $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ firstRunDateGapInHours $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ firstRunDateGapInMinutes $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ firstRunDateGapInSeconds $$HASH_SET$$;

	public TaskExecutionInfoSearch()
	{
	}
	public java.lang.Integer getTaskExecutionInfoSearchId()
	{
		return this.taskExecutionInfoId;
	}
	public void setTaskExecutionInfoSearchId(java.lang.Integer messageQueueId)
	{
		this.taskExecutionInfoId = taskExecutionInfoId;
	}
		public $$JAVA_FIELD_TYPE$$ getTaskTimeCalculationType()
	{
		return this.taskTimeCalculationType;
	}
	public void setTaskTimeCalculationType($$JAVA_FIELD_TYPE$$ taskTimeCalculationType)
	{
		this.taskTimeCalculationType = taskTimeCalculationType;
	}
	public $$JAVA_FIELD_TYPE$$ getFirstRunDateCalculationMethod()
	{
		return this.firstRunDateCalculationMethod;
	}
	public void setFirstRunDateCalculationMethod($$JAVA_FIELD_TYPE$$ firstRunDateCalculationMethod)
	{
		this.firstRunDateCalculationMethod = firstRunDateCalculationMethod;
	}
	public $$JAVA_FIELD_TYPE$$ getFirstRunDateGapInYears()
	{
		return this.firstRunDateGapInYears;
	}
	public void setFirstRunDateGapInYears($$JAVA_FIELD_TYPE$$ firstRunDateGapInYears)
	{
		this.firstRunDateGapInYears = firstRunDateGapInYears;
	}
	public $$JAVA_FIELD_TYPE$$ getFirstRunDateGapInMonths()
	{
		return this.firstRunDateGapInMonths;
	}
	public void setFirstRunDateGapInMonths($$JAVA_FIELD_TYPE$$ firstRunDateGapInMonths)
	{
		this.firstRunDateGapInMonths = firstRunDateGapInMonths;
	}
	public $$JAVA_FIELD_TYPE$$ getFirstRunDateGapInDays()
	{
		return this.firstRunDateGapInDays;
	}
	public void setFirstRunDateGapInDays($$JAVA_FIELD_TYPE$$ firstRunDateGapInDays)
	{
		this.firstRunDateGapInDays = firstRunDateGapInDays;
	}
	public $$JAVA_FIELD_TYPE$$ getFirstRunDateGapInHours()
	{
		return this.firstRunDateGapInHours;
	}
	public void setFirstRunDateGapInHours($$JAVA_FIELD_TYPE$$ firstRunDateGapInHours)
	{
		this.firstRunDateGapInHours = firstRunDateGapInHours;
	}
	public $$JAVA_FIELD_TYPE$$ getFirstRunDateGapInMinutes()
	{
		return this.firstRunDateGapInMinutes;
	}
	public void setFirstRunDateGapInMinutes($$JAVA_FIELD_TYPE$$ firstRunDateGapInMinutes)
	{
		this.firstRunDateGapInMinutes = firstRunDateGapInMinutes;
	}
	public $$JAVA_FIELD_TYPE$$ getFirstRunDateGapInSeconds()
	{
		return this.firstRunDateGapInSeconds;
	}
	public void setFirstRunDateGapInSeconds($$JAVA_FIELD_TYPE$$ firstRunDateGapInSeconds)
	{
		this.firstRunDateGapInSeconds = firstRunDateGapInSeconds;
	}

	private Date vwLastModifiedDate;
	private java.lang.Integer vwLastModifiedTime;
	private java.lang.String vwLastAction;
	private java.lang.String vwModifiedBy;
	private java.lang.String vwTxnRemarks;
	private java.lang.String vwTxnStatus;
	private java.lang.Integer isRequestUnderProcesss;
	private java.lang.Integer legacyRecordId;
	public Date getVwLastModifiedDate()
	{
		return this.vwLastModifiedDate;
	}
	public void setVwLastModifiedDate(Date vwLastModifiedDate)
	{
		this.vwLastModifiedDate = vwLastModifiedDate;
	}
	public Integer getVwLastModifiedTime()
	{
		return this.vwLastModifiedTime;
	}
	public void setVwLastModifiedTime(Integer vwLastModifiedTime)
	{
		this.vwLastModifiedTime = vwLastModifiedTime;
	}
	public String getVwLastAction()
	{
		return this.vwLastAction;
	}
	public void setVwLastAction(String vwLastAction)
	{
		this.vwLastAction = vwLastAction;
	}
	public String getVwModifiedBy()
	{
		return this.vwModifiedBy;
	}
	public void setVwModifiedBy(String vwModifiedBy)
	{
		this.vwModifiedBy = vwModifiedBy;
	}
	public String getVwTxnRemarks()
	{
		return this.vwTxnRemarks;
	}
	public void setVwTxnRemarks(String vwTxnRemarks)
	{
		this.vwTxnRemarks = vwTxnRemarks;
	}
	public String getVwTxnStatus()
	{
		return this.vwTxnStatus;
	}
	public void setVwTxnStatus(String vwTxnStatus)
	{
		this.vwTxnStatus = vwTxnStatus;
	}
	public Integer getIsRequestUnderProcesss()
	{
		return this.isRequestUnderProcesss;
	}
	public void setIsRequestUnderProcesss(Integer isRequestUnderProcesss)
	{
		this.isRequestUnderProcesss = isRequestUnderProcesss;
	}
	public Integer getLegacyRecordId()
	{
		return this.legacyRecordId;
	}
	public void setLegacyRecordId(Integer legacyRecordId)
	{
		this.legacyRecordId = legacyRecordId;
	}*/
}
