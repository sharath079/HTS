

function doAfterPanelRefreshedForUserInfoExt()
{
    //Custom handling
}



function doAfterPanelInitializedForUserInfoExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForUserInfoExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForUserInfoExt(fieldName)
{
    //Custom handling
}



function processResultRowForUserInfoExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForUserInfoExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForUserInfoExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForUserInfoExt(customEventName)
{
    //Custom handling
}

