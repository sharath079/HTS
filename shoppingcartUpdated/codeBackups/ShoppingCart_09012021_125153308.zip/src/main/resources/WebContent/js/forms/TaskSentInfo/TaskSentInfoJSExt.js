

function doAfterPanelRefreshedForTaskSentInfoExt()
{
    //Custom handling
}



function doAfterPanelInitializedForTaskSentInfoExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForTaskSentInfoExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForTaskSentInfoExt(fieldName)
{
    //Custom handling
}



function processResultRowForTaskSentInfoExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForTaskSentInfoExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForTaskSentInfoExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForTaskSentInfoExt(customEventName)
{
    //Custom handling
}

