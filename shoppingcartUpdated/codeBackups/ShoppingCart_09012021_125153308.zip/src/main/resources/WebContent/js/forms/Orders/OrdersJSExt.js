

function doAfterPanelRefreshedForOrdersExt()
{
    //Custom handling
}



function doAfterPanelInitializedForOrdersExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForOrdersExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForOrdersExt(fieldName)
{
    //Custom handling
}



function processResultRowForOrdersExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForOrdersExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForOrdersExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForOrdersExt(customEventName)
{
    //Custom handling
}

