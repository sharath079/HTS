function initializePageOnLoadForTaskLayoutParameters()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForTaskLayoutParameters;
