drop database shoppingcart;
create database shoppingcart;
use shoppingcart;
source MYSQLDML.sql;
