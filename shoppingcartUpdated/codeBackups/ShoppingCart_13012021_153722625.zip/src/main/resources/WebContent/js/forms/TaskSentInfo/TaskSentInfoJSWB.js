function initializePageOnLoadForTaskSentInfo()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForTaskSentInfo;
