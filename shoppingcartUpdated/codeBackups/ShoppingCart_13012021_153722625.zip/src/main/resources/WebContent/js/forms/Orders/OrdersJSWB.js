function initializePageOnLoadForOrders()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForOrders;
