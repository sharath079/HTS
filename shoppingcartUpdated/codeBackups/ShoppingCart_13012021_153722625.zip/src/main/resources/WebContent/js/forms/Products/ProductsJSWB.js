function initializePageOnLoadForProducts()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForProducts;
