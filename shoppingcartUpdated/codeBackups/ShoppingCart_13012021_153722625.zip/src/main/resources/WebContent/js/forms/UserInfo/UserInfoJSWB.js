function initializePageOnLoadForUserInfo()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForUserInfo;
