

function doAfterPanelRefreshedForUserCartExt()
{
    //Custom handling
}



function doAfterPanelInitializedForUserCartExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForUserCartExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForUserCartExt(fieldName)
{
    //Custom handling
}



function processResultRowForUserCartExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForUserCartExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForUserCartExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForUserCartExt(customEventName)
{
    //Custom handling
}

