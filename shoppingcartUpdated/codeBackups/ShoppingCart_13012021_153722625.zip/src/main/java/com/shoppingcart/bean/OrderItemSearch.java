package com.shoppingcart.bean;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import com.vw.runtime.RulesBean;
@SuppressWarnings("unused")
/**
 * @author  Srikanth Brahmadevara: Harivara Technology Solutions, CODE GENERATED
 */
public class OrderItemSearch extends RulesBean implements java.io.Serializable
{
	/*private static final long serialVersionUID = 1L;
	private java.lang.Integer orderItemId ;
		private $$JAVA_FIELD_TYPE$$ oid $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ prodId $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ prodQnty $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ prodUnitPrice $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ subTotalAmt $$HASH_SET$$;

	public OrderItemSearch()
	{
	}
	public java.lang.Integer getOrderItemSearchId()
	{
		return this.orderItemId;
	}
	public void setOrderItemSearchId(java.lang.Integer messageQueueId)
	{
		this.orderItemId = orderItemId;
	}
		public $$JAVA_FIELD_TYPE$$ getOid()
	{
		return this.oid;
	}
	public void setOid($$JAVA_FIELD_TYPE$$ oid)
	{
		this.oid = oid;
	}
	public $$JAVA_FIELD_TYPE$$ getProdId()
	{
		return this.prodId;
	}
	public void setProdId($$JAVA_FIELD_TYPE$$ prodId)
	{
		this.prodId = prodId;
	}
	public $$JAVA_FIELD_TYPE$$ getProdQnty()
	{
		return this.prodQnty;
	}
	public void setProdQnty($$JAVA_FIELD_TYPE$$ prodQnty)
	{
		this.prodQnty = prodQnty;
	}
	public $$JAVA_FIELD_TYPE$$ getProdUnitPrice()
	{
		return this.prodUnitPrice;
	}
	public void setProdUnitPrice($$JAVA_FIELD_TYPE$$ prodUnitPrice)
	{
		this.prodUnitPrice = prodUnitPrice;
	}
	public $$JAVA_FIELD_TYPE$$ getSubTotalAmt()
	{
		return this.subTotalAmt;
	}
	public void setSubTotalAmt($$JAVA_FIELD_TYPE$$ subTotalAmt)
	{
		this.subTotalAmt = subTotalAmt;
	}

	private Date vwLastModifiedDate;
	private java.lang.Integer vwLastModifiedTime;
	private java.lang.String vwLastAction;
	private java.lang.String vwModifiedBy;
	private java.lang.String vwTxnRemarks;
	private java.lang.String vwTxnStatus;
	private java.lang.Integer isRequestUnderProcesss;
	private java.lang.Integer legacyRecordId;
	public Date getVwLastModifiedDate()
	{
		return this.vwLastModifiedDate;
	}
	public void setVwLastModifiedDate(Date vwLastModifiedDate)
	{
		this.vwLastModifiedDate = vwLastModifiedDate;
	}
	public Integer getVwLastModifiedTime()
	{
		return this.vwLastModifiedTime;
	}
	public void setVwLastModifiedTime(Integer vwLastModifiedTime)
	{
		this.vwLastModifiedTime = vwLastModifiedTime;
	}
	public String getVwLastAction()
	{
		return this.vwLastAction;
	}
	public void setVwLastAction(String vwLastAction)
	{
		this.vwLastAction = vwLastAction;
	}
	public String getVwModifiedBy()
	{
		return this.vwModifiedBy;
	}
	public void setVwModifiedBy(String vwModifiedBy)
	{
		this.vwModifiedBy = vwModifiedBy;
	}
	public String getVwTxnRemarks()
	{
		return this.vwTxnRemarks;
	}
	public void setVwTxnRemarks(String vwTxnRemarks)
	{
		this.vwTxnRemarks = vwTxnRemarks;
	}
	public String getVwTxnStatus()
	{
		return this.vwTxnStatus;
	}
	public void setVwTxnStatus(String vwTxnStatus)
	{
		this.vwTxnStatus = vwTxnStatus;
	}
	public Integer getIsRequestUnderProcesss()
	{
		return this.isRequestUnderProcesss;
	}
	public void setIsRequestUnderProcesss(Integer isRequestUnderProcesss)
	{
		this.isRequestUnderProcesss = isRequestUnderProcesss;
	}
	public Integer getLegacyRecordId()
	{
		return this.legacyRecordId;
	}
	public void setLegacyRecordId(Integer legacyRecordId)
	{
		this.legacyRecordId = legacyRecordId;
	}*/
}
