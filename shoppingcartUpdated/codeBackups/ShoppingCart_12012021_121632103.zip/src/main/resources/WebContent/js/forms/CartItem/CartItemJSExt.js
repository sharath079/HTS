

function doAfterPanelRefreshedForCartItemExt()
{
    //Custom handling
}



function doAfterPanelInitializedForCartItemExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForCartItemExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForCartItemExt(fieldName)
{
    //Custom handling
}



function processResultRowForCartItemExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForCartItemExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForCartItemExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForCartItemExt(customEventName)
{
    //Custom handling
}

