

function doAfterPanelRefreshedForOrderItemExt()
{
    //Custom handling
}



function doAfterPanelInitializedForOrderItemExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForOrderItemExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForOrderItemExt(fieldName)
{
    //Custom handling
}



function processResultRowForOrderItemExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForOrderItemExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForOrderItemExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForOrderItemExt(customEventName)
{
    //Custom handling
}

