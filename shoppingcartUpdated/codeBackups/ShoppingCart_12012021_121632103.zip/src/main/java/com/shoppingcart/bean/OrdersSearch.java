package com.shoppingcart.bean;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import com.vw.runtime.RulesBean;
@SuppressWarnings("unused")
/**
 * @author  Srikanth Brahmadevara: Harivara Technology Solutions, CODE GENERATED
 */
public class OrdersSearch extends RulesBean implements java.io.Serializable
{
	/*private static final long serialVersionUID = 1L;
	private java.lang.Integer ordersId ;
		private $$JAVA_FIELD_TYPE$$ uid $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ orderNo $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ orderDate $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ orderAmount $$HASH_SET$$;

	public OrdersSearch()
	{
	}
	public java.lang.Integer getOrdersSearchId()
	{
		return this.ordersId;
	}
	public void setOrdersSearchId(java.lang.Integer messageQueueId)
	{
		this.ordersId = ordersId;
	}
		public $$JAVA_FIELD_TYPE$$ getUid()
	{
		return this.uid;
	}
	public void setUid($$JAVA_FIELD_TYPE$$ uid)
	{
		this.uid = uid;
	}
	public $$JAVA_FIELD_TYPE$$ getOrderNo()
	{
		return this.orderNo;
	}
	public void setOrderNo($$JAVA_FIELD_TYPE$$ orderNo)
	{
		this.orderNo = orderNo;
	}
	public $$JAVA_FIELD_TYPE$$ getOrderDate()
	{
		return this.orderDate;
	}
	public void setOrderDate($$JAVA_FIELD_TYPE$$ orderDate)
	{
		this.orderDate = orderDate;
	}
	public $$JAVA_FIELD_TYPE$$ getOrderAmount()
	{
		return this.orderAmount;
	}
	public void setOrderAmount($$JAVA_FIELD_TYPE$$ orderAmount)
	{
		this.orderAmount = orderAmount;
	}

	private Date vwLastModifiedDate;
	private java.lang.Integer vwLastModifiedTime;
	private java.lang.String vwLastAction;
	private java.lang.String vwModifiedBy;
	private java.lang.String vwTxnRemarks;
	private java.lang.String vwTxnStatus;
	private java.lang.Integer isRequestUnderProcesss;
	private java.lang.Integer legacyRecordId;
	public Date getVwLastModifiedDate()
	{
		return this.vwLastModifiedDate;
	}
	public void setVwLastModifiedDate(Date vwLastModifiedDate)
	{
		this.vwLastModifiedDate = vwLastModifiedDate;
	}
	public Integer getVwLastModifiedTime()
	{
		return this.vwLastModifiedTime;
	}
	public void setVwLastModifiedTime(Integer vwLastModifiedTime)
	{
		this.vwLastModifiedTime = vwLastModifiedTime;
	}
	public String getVwLastAction()
	{
		return this.vwLastAction;
	}
	public void setVwLastAction(String vwLastAction)
	{
		this.vwLastAction = vwLastAction;
	}
	public String getVwModifiedBy()
	{
		return this.vwModifiedBy;
	}
	public void setVwModifiedBy(String vwModifiedBy)
	{
		this.vwModifiedBy = vwModifiedBy;
	}
	public String getVwTxnRemarks()
	{
		return this.vwTxnRemarks;
	}
	public void setVwTxnRemarks(String vwTxnRemarks)
	{
		this.vwTxnRemarks = vwTxnRemarks;
	}
	public String getVwTxnStatus()
	{
		return this.vwTxnStatus;
	}
	public void setVwTxnStatus(String vwTxnStatus)
	{
		this.vwTxnStatus = vwTxnStatus;
	}
	public Integer getIsRequestUnderProcesss()
	{
		return this.isRequestUnderProcesss;
	}
	public void setIsRequestUnderProcesss(Integer isRequestUnderProcesss)
	{
		this.isRequestUnderProcesss = isRequestUnderProcesss;
	}
	public Integer getLegacyRecordId()
	{
		return this.legacyRecordId;
	}
	public void setLegacyRecordId(Integer legacyRecordId)
	{
		this.legacyRecordId = legacyRecordId;
	}*/
}
