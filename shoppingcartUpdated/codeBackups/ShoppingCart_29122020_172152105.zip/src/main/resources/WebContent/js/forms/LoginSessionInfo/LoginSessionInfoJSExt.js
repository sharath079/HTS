

function doAfterPanelRefreshedForLoginSessionInfoExt()
{
    //Custom handling
}



function doAfterPanelInitializedForLoginSessionInfoExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForLoginSessionInfoExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForLoginSessionInfoExt(fieldName)
{
    //Custom handling
}



function processResultRowForLoginSessionInfoExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForLoginSessionInfoExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForLoginSessionInfoExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForLoginSessionInfoExt(customEventName)
{
    //Custom handling
}

