

function doAfterPanelRefreshedForProductsExt()
{
    //Custom handling
}



function doAfterPanelInitializedForProductsExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForProductsExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForProductsExt(fieldName)
{
    //Custom handling
}



function processResultRowForProductsExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForProductsExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForProductsExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForProductsExt(customEventName)
{
    //Custom handling
}

