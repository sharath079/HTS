function initializePageOnLoadForEmployeeRoles()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForEmployeeRoles;
