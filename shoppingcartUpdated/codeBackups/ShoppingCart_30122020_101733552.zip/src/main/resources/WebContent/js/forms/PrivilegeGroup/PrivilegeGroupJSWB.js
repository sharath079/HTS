function initializePageOnLoadForPrivilegeGroup()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForPrivilegeGroup;
