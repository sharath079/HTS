function initializePageOnLoadForOrderItem()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForOrderItem;
