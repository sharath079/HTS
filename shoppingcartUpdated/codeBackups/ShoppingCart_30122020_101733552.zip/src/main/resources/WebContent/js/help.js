function showMessage()
{
	alert("From JS file !!");   
}

