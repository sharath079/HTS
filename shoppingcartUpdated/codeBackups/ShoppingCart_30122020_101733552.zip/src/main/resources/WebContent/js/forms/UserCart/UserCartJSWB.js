function initializePageOnLoadForUserCart()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForUserCart;
